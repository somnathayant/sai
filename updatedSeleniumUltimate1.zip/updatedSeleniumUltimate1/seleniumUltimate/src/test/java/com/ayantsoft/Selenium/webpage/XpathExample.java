package com.ayantsoft.Selenium.webpage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class XpathExample {

	
	@Test
	public void testCssSelector(){

		WebDriver driver = new FirefoxDriver();

		String baseUrl = "http://localhost:8081/seleniumUltimate/";	
		driver.get(baseUrl);

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

		/*WebElement userId = driver.findElement(By.id("userid"));					 
		WebElement userPass = driver.findElement(By.id("password"));					 
		*/
		
		WebElement radioOption = driver.findElement(By.id("empType"));					 
		WebElement chk1 = driver.findElement(By.id("wage1"));					 
		WebElement chk2 = driver.findElement(By.id("wage2"));					 
		WebElement chk3 = driver.findElement(By.id("wage3"));					 
		
		//Xpath=//input[name=’email’][@placeholder=’Work Email’]
		
		
		
		  //Relative xpath 
		WebElement userPass= driver.findElement(By.xpath("//input[@id='password']"));
		//Relative xpath 
		//WebElement userId=driver.findElement(By.xpath("//input[@id='userid']"));
      
		
		//multiple indentifier using xpath 
				WebElement userId=driver.findElement(By.xpath("//input[@id='userid'][@class='usr-id']"));
			   
		
		
		//multiple indentifier using xpath using or /and
		
		//WebElement userId=driver.findElement(By.xpath("//input[@id='userid' or @class='usr-id']"));
	      
		
		
		
		radioOption.click();//checks the radio so validation wont work if you dont do it validation work
		chk1.click();
		//you can do same as of radio button with checkboxes namely chk1,chk2,chk3

		userId.sendKeys();//no words so validation works
		userPass.sendKeys("selenium@123");//password less or greater then 5 words so validation works

		JavascriptExecutor js =(JavascriptExecutor)driver;

		js.executeScript("done();");




	}


	
	
}
