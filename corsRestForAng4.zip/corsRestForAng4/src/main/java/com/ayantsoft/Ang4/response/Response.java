package com.ayantsoft.Ang4.response;

import java.io.Serializable;

public class Response implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 7899023101327447031L;

	
	//setter and getter
	
	private String msg;

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	
	
	
	
}
