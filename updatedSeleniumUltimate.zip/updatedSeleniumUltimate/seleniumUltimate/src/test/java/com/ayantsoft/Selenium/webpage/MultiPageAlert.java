package com.ayantsoft.Selenium.webpage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

//This program shows the use of multiple page with alert box
//right click on this file and select run as either java application or testNG
public class MultiPageAlert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try{
			WebDriver driver = new FirefoxDriver();

			String baseUrl = "http://localhost:8081/seleniumUltimate/";	
			driver.get(baseUrl);

			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			WebElement secondPage = driver.findElement(By.id("secondPage"));					 

			secondPage.click();
			/* Find the button which can trigger popup by it's id. */
			By byId = By.id("btnClick");

			WebElement alertBtn = driver.findElement(byId);

			if(alertBtn!=null)
			{
				/* Click the button to trigger a javascript 
				 * which will popup an dialog.*/
				alertBtn.click();
			}

			/* 
			 * You can process javascript alert, confirm and prompt
			 * with this object.
			 * */
			Alert alertObj = driver.switchTo().alert();

			/* Print out the popup text in the console. */
			System.out.println(alertObj.getText());

			/* Sleep 3 seconds to see the popup dialog. */
			Thread.sleep(3000);

			/* Accept this javascript popup and close it. */
			alertObj.accept();

			System.out.println("Click OK button automatically in testAlertInSelenium method.");
			Thread.sleep(2000);

			WebElement back = driver.findElement(By.id("firstPage"));					 

			back.click();


		}catch(Exception ex){

		}

		
		
	}

	@Test
	public void fun(){

		try{
			WebDriver driver = new FirefoxDriver();

			String baseUrl = "http://localhost:8081/seleniumUltimate/";	
			driver.get(baseUrl);

			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

			WebElement secondPage = driver.findElement(By.id("secondPage"));					 

			secondPage.click();
			/* Find the button which can trigger popup by it's id. */
			By byId = By.id("btnClick");

			WebElement alertBtn = driver.findElement(byId);

			if(alertBtn!=null)
			{
				/* Click the button to trigger a javascript 
				 * which will popup an dialog.*/
				alertBtn.click();
			}

			/* 
			 * You can process javascript alert, confirm and prompt
			 * with this object.
			 * */
			Alert alertObj = driver.switchTo().alert();

			/* Print out the popup text in the console. */
			System.out.println(alertObj.getText());

			/* Sleep 3 seconds to see the popup dialog. */
			Thread.sleep(3000);

			/* Accept this javascript popup and close it. */
			alertObj.accept();

			System.out.println("Click OK button automatically in testAlertInSelenium method.");
			Thread.sleep(2000);

			WebElement back = driver.findElement(By.id("firstPage"));					 

			back.click();


		}catch(Exception ex){

		}

	}


}
