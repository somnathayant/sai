package com.ayant.test.examples;

import org.junit.jupiter.api.Test;

import com.ayant.examples.CodeLogic;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TestCodeLogic {

    @Test
    public void testMethod() {

        CodeLogic obj = new CodeLogic();
        assertEquals("Hello Somnath", obj.testWithString("Somnath"));

    }

    /*@Test
    public void testNameEmpty() {

        MessageBuilder obj = new MessageBuilder();
        assertEquals("Please provide a name!", obj.getMessage(" "));

    }

    @Test
    public void testNameNull() {

        MessageBuilder obj = new MessageBuilder();
        assertEquals("Please provide a name!", obj.getMessage(null));

    }*/

}